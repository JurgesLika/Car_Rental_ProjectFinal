package com.carrentalproject.Car_Rental_Spring.enums;

public enum BookCarStatus {
    PENDING,APPROVED,REJECTED
}
