package Service;

public interface ServiceInterface {

}
