package com.carrentalproject.Car_Rental_Spring.dto;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

import java.util.Date;

@Data
public class CarDto {
    private Long id;

    private String name;

    private String brand;

    private String type;

    private String transmission;

    private String description;

    private Long Price;

    private Date year;

    private MultipartFile image;

    private byte[] returnedImage;

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getBrand() {
        return brand;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setTransmission(String transmission) {
        this.transmission = transmission;
    }

    public String getTransmission() {
        return transmission;
    }

    public void setYear(Date year) {
        this.year = year;
    }

    public void setReturnedImage(byte[] returnedImage) {
        this.returnedImage = returnedImage;
    }
}
