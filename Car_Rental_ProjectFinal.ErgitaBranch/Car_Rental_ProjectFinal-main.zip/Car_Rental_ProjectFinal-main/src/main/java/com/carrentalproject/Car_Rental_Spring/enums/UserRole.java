package com.carrentalproject.Car_Rental_Spring.enums;

public enum UserRole {
    ADMIN,
    CUSTOMER,

}
